/**
 * Universal Collection Card Display Rules
 *
 * These rules determine aspect ratios and responsive behavior based on the number of cards in a section.
 * These rules apply to ALL collection sections across the entire site.
 *
 * Rules by card count:
 *
 * 1 card (promo):
 *   - Aspect ratio: 16:9 on all screen sizes
 *
 * 2 cards:
 *   - Aspect ratio: 5:3 on all screen sizes
 *
 * 3 cards:
 *   - Aspect ratio: 1:1 on desktop/tablet, 4:3 on mobile
 *
 * 4 cards:
 *   - Aspect ratio: 1:1 on desktop/tablet, 4:3 on mobile
 *   - Layout: 2x2 grid on tablet, row on desktop
 *   - Mobile: Show only 3 cards (hide 4th)
 *
 * 5 cards:
 *   - Aspect ratio: 1:1 on desktop/tablet, 4:3 on mobile
 *   - Tablet/Mobile: Show only 3 cards (hide last 2)
 */

export type CollectionCardCount = 1 | 2 | 3 | 4 | 5

export interface CollectionDisplayRules {
  aspectRatio: "16-9" | "5-3" | "1-1" | "4-3"
  hideOnMobile: boolean
  hideOnTablet: boolean
}

export function getCollectionCardRules(count: CollectionCardCount, index: number): CollectionDisplayRules {
  switch (count) {
    case 1:
      return {
        aspectRatio: "16-9",
        hideOnMobile: false,
        hideOnTablet: false,
      }

    case 2:
      return {
        aspectRatio: "5-3",
        hideOnMobile: false,
        hideOnTablet: false,
      }

    case 3:
      return {
        aspectRatio: "1-1",
        hideOnMobile: false,
        hideOnTablet: false,
      }

    case 4:
      return {
        aspectRatio: "1-1",
        hideOnMobile: index >= 3, // Hide 4th card on mobile
        hideOnTablet: false,
      }

    case 5:
      return {
        aspectRatio: "1-1",
        hideOnMobile: index >= 3, // Hide 4th and 5th cards on mobile
        hideOnTablet: index >= 3, // Hide 4th and 5th cards on tablet
      }

    default:
      return {
        aspectRatio: "16-9",
        hideOnMobile: false,
        hideOnTablet: false,
      }
  }
}

export function getCollectionSectionLayout(count: CollectionCardCount): string {
  switch (count) {
    case 1:
      return "flex gap-2 md:gap-3 lg:gap-4 w-full"

    case 2:
      return "flex flex-col md:flex-row gap-2 md:gap-3 lg:gap-4 w-full"

    case 3:
      return "flex flex-col md:flex-row gap-2 md:gap-3 lg:gap-4 w-full"

    case 4:
      return "flex flex-col md:grid md:grid-cols-2 lg:flex lg:flex-row gap-2 md:gap-3 lg:gap-4 w-full"

    case 5:
      return "flex flex-col md:flex-row gap-2 md:gap-3 lg:gap-4 w-full"

    default:
      return "flex flex-col md:flex-row gap-2 md:gap-3 lg:gap-4 w-full"
  }
}
